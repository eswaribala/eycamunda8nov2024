---
name: General Issue
about: Submit an issue/bug related to the self-managed, docker compose deployment
  method. All other questions should go to https://forums.camunda.io
title: ''
labels: ''
assignees: ''

---


